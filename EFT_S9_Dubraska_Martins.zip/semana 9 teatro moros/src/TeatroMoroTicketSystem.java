import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TeatroMoroTicketSystem {

    private final String nombreTeatro;
    private final HashMap<String, Integer> preciosUbicacionesTeatro;
    private final HashMap<String, Integer> preciosUbicacionesConcierto;
    private final int capacidadSala;
    private final int[][] asientosDisponiblesTeatro;
    private final int[][] asientosDisponiblesConcierto;

    private static int totalIngresos = 0;
    private static int totalEntradasVendidas = 0;

    // Lista para almacenar las ventas
    private final ArrayList<Venta> ventas = new ArrayList<>();

    // Constructor
    public TeatroMoroTicketSystem(String nombreTeatro, HashMap<String, Integer> preciosUbicacionesTeatro, HashMap<String, Integer> preciosUbicacionesConcierto, int capacidadSala) {
        this.nombreTeatro = nombreTeatro;
        this.preciosUbicacionesTeatro = preciosUbicacionesTeatro;
        this.preciosUbicacionesConcierto = preciosUbicacionesConcierto;
        this.capacidadSala = capacidadSala;
        this.asientosDisponiblesTeatro = new int[capacidadSala][capacidadSala];
        this.asientosDisponiblesConcierto = new int[capacidadSala][capacidadSala];
        // Inicializar asientos disponibles para teatro y concierto
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                this.asientosDisponiblesTeatro[i][j] = 1; // 1 indica que el asiento está disponible
                this.asientosDisponiblesConcierto[i][j] = 1; // 1 indica que el asiento está disponible
            }
        }
    }

    // Método para mostrar el menú interactivo
    public void mostrarMenu() {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean salir = false;
            while (!salir) {
                System.out.println("---- Menu ----");
                System.out.println("1. Venta de entradas");
                System.out.println("2. Visualizar resumen de ventas");
                System.out.println("3. Generar boleta");
                System.out.println("4. Eliminar entrada");
                System.out.println("5. Modificar entrada");
                System.out.println("6. Ver plano de asientos (Teatro)");
                System.out.println("7. Ver plano de asientos (Concierto)");
                System.out.println("8. Calcular Ingresos Totales");
                System.out.println("9. Salir del Programa");
                System.out.print("Seleccione una opcion: ");
                int opcion;
                try {
                    opcion = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Debe ingresar un numero.");
                    continue;
                }
                switch (opcion) {
                    case 1 -> ventaEntradas(scanner);
                    case 2 -> visualizarResumenVentas();
                    case 3 -> generarBoleta();
                    case 4 -> eliminarEntrada(scanner);
                    case 5 -> modificarEntrada(scanner);
                    case 6 -> mostrarPlanoAsientos("teatro");
                    case 7 -> mostrarPlanoAsientos("concierto");
                    case 8 -> calcularIngresosTotales();
                    case 9 -> {
                        System.out.println("Gracias por su compra");
                        salir = true;
                    }
                    default -> System.out.println("Opcion no valida");
                }
            }
        }
    }

    // Método para realizar la venta de entradas
    private void ventaEntradas(Scanner scanner) {
        System.out.println("---- Venta de Entradas ----");
        System.out.print("RUT del cliente (solo numeros): ");
        String rutCliente = scanner.nextLine();
        if (!rutCliente.matches("\\d+")) {
            System.out.println("RUT no valido. Debe ingresar solo numeros.");
            return;
        }
        System.out.print("Nombre del cliente (solo letras): ");
        String nombreCliente = scanner.nextLine();
        if (!nombreCliente.matches("[a-zA-Z ]+")) {
            System.out.println("Nombre no valido. Debe ingresar solo letras.");
            return;
        }
        System.out.print("Seleccione el tipo de evento (teatro/concierto): ");
        String tipoEvento = scanner.nextLine().toLowerCase();
        if (!tipoEvento.equals("teatro") && !tipoEvento.equals("concierto")) {
            System.out.println("Tipo de evento no valido.");
            return;
        }
        HashMap<String, Integer> preciosUbicaciones = (tipoEvento.equals("teatro")) ? preciosUbicacionesTeatro : preciosUbicacionesConcierto;
        int[][] asientosDisponibles = (tipoEvento.equals("teatro")) ? asientosDisponiblesTeatro : asientosDisponiblesConcierto;

        System.out.print("Seleccione la ubicacion (VIP, PLATEA, BALCON): ");
        String ubicacion = scanner.nextLine().toUpperCase();
        if (!preciosUbicaciones.containsKey(ubicacion)) {
            System.out.println("Ubicacion no valida.");
            return;
        }

        System.out.print("Fila del asiento: ");
        int filaAsiento;
        try {
            filaAsiento = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Debe ingresar un numero para la fila del asiento.");
            return;
        }

        System.out.print("Columna del asiento: ");
        int columnaAsiento;
        try {
            columnaAsiento = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Debe ingresar un numero para la columna del asiento.");
            return;
        }

        if (!esAsientoValido(filaAsiento, columnaAsiento)) {
            System.out.println("La fila o columna del asiento no es valida.");
            return;
        }

        if (asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] == 0) {
            System.out.println("El asiento seleccionado no esta disponible.");
            return;
        }

        System.out.print("Es estudiante? (SI/NO): ");
        boolean esEstudiante = scanner.nextLine().equalsIgnoreCase("si");
        System.out.print("Es de la tercera edad? (SI/NO): ");
        boolean esPersonaMayor = scanner.nextLine().equalsIgnoreCase("si");

        int descuento = 0;
        if (esEstudiante) {
            descuento = 10;
        } else if (esPersonaMayor) {
            descuento = 15;
        }

        int precioBase = preciosUbicaciones.get(ubicacion);
        int costoFinal = precioBase - (precioBase * descuento / 100);

        // Disponibilidad de entradas
        if (asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] == 1) {
            asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] = 0; // Marcar asiento como ocupado
            totalEntradasVendidas++;
            totalIngresos += costoFinal;
            int entradasDisponibles = actualizarEntradasDisponibles(ubicacion, tipoEvento); // Actualizar cantidad de entradas disponibles
            ventas.add(new Venta(rutCliente, nombreCliente, ubicacion, filaAsiento, columnaAsiento, costoFinal, descuento, entradasDisponibles, tipoEvento));
            System.out.println("Venta realizada con Exito!");
        } else {
            System.out.println("Lo siento, el asiento seleccionado ya esta ocupado.");
        }
    }

    // Método para actualizar la cantidad de entradas disponibles
    private int actualizarEntradasDisponibles(String ubicacion, String tipoEvento) {
        int[][] asientosDisponibles = (tipoEvento.equals("teatro")) ? asientosDisponiblesTeatro : asientosDisponiblesConcierto;
        int entradas = 0;
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                if (asientosDisponibles[i][j] == 1) {
                    entradas++;
                }
            }
        }
        return entradas;
    }

    // Método para visualizar el resumen de ventas
    private void visualizarResumenVentas() {
        System.out.println("---- Resumen de Ventas ----");
        for (Venta venta : ventas) {
            System.out.println("RUT Cliente: " + venta.rutCliente);
            System.out.println("Nombre Cliente: " + venta.nombreCliente);
            System.out.println("Ubicación: " + venta.ubicacion);
            System.out.println("Fila Asiento: " + venta.filaAsiento);
            System.out.println("Columna Asiento: " + venta.columnaAsiento);
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
            System.out.println("Tipo de Evento: " + venta.tipoEvento);
            System.out.println("--------------------------");
        }
    }

    // Método para generar la boleta
    private void generarBoleta() {
        System.out.println("-------------------------");
        System.out.println("      TEATRO MORO     ");
        System.out.println("-------------------------");
        System.out.println("        Boleta         ");
        System.out.println("-------------------------");
        for (Venta venta : ventas) {
            System.out.println("ID Venta: " + venta.idVenta);
            System.out.println("RUT Cliente: " + venta.rutCliente);
            System.out.println("Nombre Cliente: " + venta.nombreCliente);
            System.out.println("Ubicación: " + venta.ubicacion);
            System.out.println("Asiento: Fila " + venta.filaAsiento + ", Columna " + venta.columnaAsiento);
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
            System.out.println("Tipo de Evento: " + venta.tipoEvento);
            System.out.println("--------------------------");
        }
        System.out.println("  Gracias por su compra   ");
        System.out.println("--------------------------");
    }

    // Método para calcular los ingresos totales
    private void calcularIngresosTotales() {
        System.out.println("Ingresos Totales: " + totalIngresos);
    }

    // Método para mostrar el plano de asientos
    private void mostrarPlanoAsientos(String tipoEvento) {
        System.out.println("---- Plano de Asientos (" + tipoEvento.toUpperCase() + ") ----");
        System.out.println("Asientos disponibles (0) y ocupados (X):");
        int[][] asientosDisponibles = (tipoEvento.equals("teatro")) ? asientosDisponiblesTeatro : asientosDisponiblesConcierto;
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                if (asientosDisponibles[i][j] == 1) {
                    System.out.print("0 ");
                } else {
                    System.out.print("X ");
                }
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }

    // Método para eliminar una entrada existente
    private void eliminarEntrada(Scanner scanner) {
        System.out.println("Ingrese el RUT del cliente cuya entrada desea eliminar:");
        String rutCliente = scanner.nextLine();
        boolean encontrado = false;
        for (Venta venta : ventas) {
            if (venta.rutCliente.equals(rutCliente)) {
                encontrado = true;
                System.out.println("Entrada encontrada:");
                System.out.println("RUT Cliente: " + venta.rutCliente);
                System.out.println("Nombre Cliente: " + venta.nombreCliente);
                System.out.println("Ubicacion: " + venta.ubicacion);
                System.out.println("Fila Asiento: " + venta.filaAsiento);
                System.out.println("Columna Asiento: " + venta.columnaAsiento);
                System.out.println("Costo Final: " + venta.costoFinal);
                System.out.println("Descuento aplicado: " + venta.descuento + "%");
                System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
                System.out.println("Tipo de Evento: " + venta.tipoEvento);
                System.out.println("Desea eliminar esta entrada? (SI/NO)");
                String respuesta = scanner.nextLine();
                if (respuesta.equalsIgnoreCase("SI")) {
                    // Eliminar entrada
                    ventas.remove(venta);
                    System.out.println("Entrada eliminada correctamente.");
                    // Liberar el asiento
                    if (venta.tipoEvento.equals("teatro")) {
                        asientosDisponiblesTeatro[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                    } else {
                        asientosDisponiblesConcierto[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                    }
                } else {
                    System.out.println("Entrada no eliminada.");
                }
                break;
            }
        }
        if (!encontrado) {
            System.out.println("RUT de cliente no encontrado.");
        }
    }

    // Método para modificar una entrada existente
    private void modificarEntrada(Scanner scanner) {
        System.out.println("Ingrese el RUT del cliente cuya entrada desea modificar:");
        String rutCliente = scanner.nextLine();
        boolean encontrado = false;
        for (Venta venta : ventas) {
            if (venta.rutCliente.equals(rutCliente)) {
                encontrado = true;
                System.out.println("Entrada encontrada:");
                System.out.println("RUT Cliente: " + venta.rutCliente);
                System.out.println("Nombre Cliente: " + venta.nombreCliente);
                System.out.println("Ubicacion: " + venta.ubicacion);
                System.out.println("Fila Asiento: " + venta.filaAsiento);
                System.out.println("Columna Asiento: " + venta.columnaAsiento);
                System.out.println("Costo Final: " + venta.costoFinal);
                System.out.println("Descuento aplicado: " + venta.descuento + "%");
                System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
                System.out.println("Tipo de Evento: " + venta.tipoEvento);
                System.out.println("Desea modificar esta entrada? (SI/NO)");
                String respuesta = scanner.nextLine();
                if (respuesta.equalsIgnoreCase("SI")) {
                    // Liberar el asiento actual
                    if (venta.tipoEvento.equals("teatro")) {
                        asientosDisponiblesTeatro[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                    } else {
                        asientosDisponiblesConcierto[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                    }
                    // Realizar una nueva venta
                    ventaEntradas(scanner);
                    // Eliminar la entrada anterior
                    ventas.remove(venta);
                } else {
                    System.out.println("Entrada no modificada.");
                }
                break;
            }
        }
        if (!encontrado) {
            System.out.println("RUT de cliente no encontrado.");
        }
    }

    // Método para verificar si un asiento es válido
    private boolean esAsientoValido(int fila, int columna) {
        return fila >= 1 && fila <= capacidadSala && columna >= 1 && columna <= capacidadSala;
    }

    // Clase interna para representar una venta
    private static class Venta {
        private static int contadorID = 1;
        private final int idVenta;
        private final String rutCliente;
        private final String nombreCliente;
        private final String ubicacion;
        private final int filaAsiento;
        private final int columnaAsiento;
        private final int costoFinal;
        private final int descuento;
        private final int entradasDisponibles;
        private final String tipoEvento;

        public Venta(String rutCliente, String nombreCliente, String ubicacion, int filaAsiento, int columnaAsiento, int costoFinal, int descuento, int entradasDisponibles, String tipoEvento) {
            this.idVenta = contadorID++;
            this.rutCliente = rutCliente;
            this.nombreCliente = nombreCliente;
            this.ubicacion = ubicacion;
            this.filaAsiento = filaAsiento;
            this.columnaAsiento = columnaAsiento;
            this.costoFinal = costoFinal;
            this.descuento = descuento;
            this.entradasDisponibles = entradasDisponibles;
            this.tipoEvento = tipoEvento;
        }
    }

    // Método main
    public static void main(String[] args) {
        HashMap<String, Integer> preciosUbicacionesTeatro = new HashMap<>();
        preciosUbicacionesTeatro.put("VIP", 100000);
        preciosUbicacionesTeatro.put("PLATEA", 80000);
        preciosUbicacionesTeatro.put("BALCON", 50000);

        HashMap<String, Integer> preciosUbicacionesConcierto = new HashMap<>();
        preciosUbicacionesConcierto.put("VIP", 250000);
        preciosUbicacionesConcierto.put("PLATEA", 200000);
        preciosUbicacionesConcierto.put("BALCON", 100000);

        TeatroMoroTicketSystem sistema = new TeatroMoroTicketSystem("Teatro Moro", preciosUbicacionesTeatro, preciosUbicacionesConcierto, 15);
        sistema.mostrarMenu();
    }
}
